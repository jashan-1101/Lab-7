function addValue(){
    var operator1 = document.getElementById("input1").value;
    var operator2 = document.getElementById("input2").value;

    val1 = parseInt(operator1, 10);
    val2 = parseInt(operator2, 10);

    var result = val1 + val2;
    
    document.getElementById("resultplace").value = result;
}
function multiplyValue(){
    var operator1 = document.getElementById("input1").value;
    var operator2 = document.getElementById("input2").value;

    val1 = parseInt(operator1, 10);
    val2 = parseInt(operator2, 10);

    var result = val1 * val2;
    document.getElementById("resultplace").value = result;
}
function ratioValue(){
    var operator1 = document.getElementById("input1").value;
    var operator2 = document.getElementById("input2").value;

    val1 = parseInt(operator1, 10);
    val2 = parseInt(operator2, 10);

    var result = val1 / val2;
    document.getElementById("resultplace").value = result
}
function clearValue(){
    document.getElementById("input1").value = '';
    document.getElementById("input2").value = '';

    document.getElementById("resultplace").value = ''
}